import HeroSection from "@/components/HeroSection";

const Index = () => {
  return (
    <main style={{ background: "#000" }}>
      <HeroSection />
    </main>
  );
};

export default Index;
